<?php

$welcome_msg = urlencode("Hello, Welcome to SKJ ORDERS BOT. Select a command from the menu to get information on how to use this bot");

$help_msg = urlencode(" Welcome to SKJ ORDERS BOT  you can place your other by clicking the menu to give SKJ Bot a command. Select a command from the menu to know to use it ");

$how_to_custom_order = urlencode("You can create a custom order by sending a photo of the product you want and adding the following details in the caption.\n\nPlease use the following format and order. Details to be provided\nBranch name\nWeight\nLength/Size\nRemarks\nDue Date.\nBelow is a sample");
$cusom_order_sample_id = "AgACAgQAAxkBAAIDMmEaZMaF7Ep6xgfIfK_PqN25Lw45AAIfuDEb9unZUKDKXKi4VMGdAQADAgADeQADIAQ";

$how_to_catalog_order = urlencode("You will receive a list of stock categories to choose from.\nSend the following command to the bot browse through the category you want to see 'show me THE CATEGORY NAME', 'i.e(show me necklace)'\n\nclick the 'NEXT' button to browse through the images.\n\nWhen you see what you like you can order it by sending the following message to the bot 'ORDER- product code',  followed by your own details see the sample below");

$catalog_order_img_sample = "AgACAgQAAxkBAAIDTWEaaoWeqmBEggie2rlf0iHaQlVdAAIjuDEb9unZUEPtlZJTRrdEAQADAgADeQADIAQ";

$category_listing = urlencode("1.Necklace\n2.Bangles\n3.Set\n4.Niddle\n5.Nakash\n6.Haaram\n7.earings\n8.Choker\n9.Casting\n10.Others"  );


$admin_command_help = "As an admin to upload to catalog send the bot a picture of the product with the product code and weight in the caption make sure it is in this format PRODUCT CODE:B002 go to new line WEIGHT:20.00gms";

function keyBoard($start){

    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => 'NEXT', 'callback_data' => $start]
            ]
            
        ]
    ];
    $keyboard = json_encode($keyboard);
    return $keyboard;
}


