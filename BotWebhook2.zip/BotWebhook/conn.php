<?php
$botuserpass = "$]Ww!W?8*VvB";
$botusername = "wwwagrog_botuser";
$botdb = "wwwagrog_bot";
$conn = mysqli_connect('localhost',$botusername,$botuserpass,$botdb);
