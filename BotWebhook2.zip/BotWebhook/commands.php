<?php
$command = array('/customorder','/stockorder','/orderstatus');

$list_of_categories = array('necklace','bangles','bangle','set','niddle','nakash','haaram','earings','chokers','choker','casting','others');
$admin_id = '132461164';